package com.pepe.app.safesurfing;

/**
 * Created by 0011445 on 14/09/2016.
 */
public interface GetterAemetURI {

    String getAemetURI(String provincia, String municipio);
}
